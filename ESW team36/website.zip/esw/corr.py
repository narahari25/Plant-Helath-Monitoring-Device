import pandas as pd

data = {
    'Day': [1, 2, 3, 4, 5, 6, 7, 8],
    'Leaf Temperature': [25.5,26.4,27.5,27.3,24.2,28,27.2,25.7],
    'Air temperature': [26.47, 27, 26.14, 27.2, 26.11, 27, 26.14, 23.9],
    'Soil Moisture': [13.4,16.6,14.1,17.2,15.8,12.9,17.2,14.6],
    'pH': [6.08,5.92,5.76,5.6,5.5,5.44,5.23,5.12]
}

df = pd.DataFrame(data)

correlation_coefficient = df['Leaf Temperature'].corr(df['Air temperature'])

# Normalize Leaf Temperature
df['Normalized Leaf Temperature'] = df['Leaf Temperature'] - correlation_coefficient * df['Air temperature']

print("Normalized DataFrame:")
print(df[['Day', 'Leaf Temperature', 'Air temperature', 'Normalized Leaf Temperature']])
