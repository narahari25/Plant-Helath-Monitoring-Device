import matplotlib.pyplot as plt
import numpy as np

# Your data
soil_moisture = np.array([14.3,14.7,15.3,15.5,15.9,13.4,16.8,18,17.2,16.4,15.8,14.7,15.2,17.4])
normalized_leaf_temp = np.array([])

# Plotting
plt.figure(figsize=(10, 6))
plt.scatter(soil_moisture, normalized_leaf_temp, marker='o')
plt.xlabel('Ph')
plt.ylabel('Leaf Temperature')
plt.title('PH vs. Leaf Temperature')
plt.grid(True)
plt.show()
