import matplotlib.pyplot as plt
import numpy as np

# Your data
soil_moisture = np.array([6.08,5.92,5.76,5.60,5.5,5.44,5.23,5.12])
normalized_leaf_temp = np.array([15.240932,15.935518,17.368831,16.758003,14.080458,17.535518,17.068831,16.436995])

# Calculate the midpoints
midpoint_x = (np.min(soil_moisture) + np.max(soil_moisture)) / 2
midpoint_y = (np.min(normalized_leaf_temp) + np.max(normalized_leaf_temp)) / 2

# Plotting
plt.figure(figsize=(10, 6))

# Plot all data points
plt.scatter(soil_moisture, normalized_leaf_temp, marker='o', color='gray')

# Add a horizontal line at the midpoint along the y-axis
plt.axhline(y=midpoint_y, color='r', linestyle='--')

# Add a vertical line at the midpoint along the x-axis
plt.axvline(x=midpoint_x, color='g', linestyle='--')
# Fill the region from the start of x-axis to the midpoint and from the midpoint of y-axis to the end with red color
plt.fill_between([np.min(soil_moisture), midpoint_x], midpoint_y, np.max(normalized_leaf_temp), color='red', alpha=0.3)
plt.fill_between([np.min(soil_moisture), midpoint_x], np.min(normalized_leaf_temp), midpoint_y, color='green', alpha=0.3)

# Fill the region from the midpoint of x-axis to the end and from the start of y-axis to the midpoint with blue color
plt.fill_between([midpoint_x, np.max(soil_moisture)], np.min(normalized_leaf_temp), midpoint_y, color='green', alpha=0.3)
plt.fill_between([midpoint_x, np.max(soil_moisture)], midpoint_y, np.max(normalized_leaf_temp), color='red', alpha=0.3)

plt.xlabel('PH')
plt.ylabel('Normalized Leaf Temperature')
plt.title('PH vs. Normalized Leaf Temperature')
plt.legend()
plt.grid(True)
plt.show()